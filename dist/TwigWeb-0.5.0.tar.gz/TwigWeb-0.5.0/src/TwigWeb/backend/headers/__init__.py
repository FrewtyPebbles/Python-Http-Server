
class Headers:
    def __init__(self, URL = {}, HEADERS = {}) -> None:
        self.URL = URL
        self.HEADERS = HEADERS